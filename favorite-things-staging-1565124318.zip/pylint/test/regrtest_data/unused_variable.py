# pylint: disable=missing-docstring

def test():
    variable = ''
    variable2 = None
    return variable2
